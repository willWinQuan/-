<template>
  <div class="row">
    <div class="blocks">
      <h3 class="text-center mt-5">Methods</h3>
      <div class="block">
        <table class="table table-responsive d-table">
          <thead>
            <tr>
              <th>方法</th>
              <th>说明</th>
              <th>参数</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><strong>province</strong></td>
              <td><strong>选择省份</strong></td>
              <td>返回省份的值</td>
            </tr>
            <tr>
              <td><strong>city</strong></td>
              <td><strong>选择城市</strong></td>
              <td>返回城市的值</td>
            </tr>
            <tr>
              <td><strong>area</strong></td>
              <td><strong>选择地区</strong></td>
              <td>返回地区的值</td>
            </tr>
            <tr>
              <td><strong>selected</strong></td>
              <td><strong>选择最后一项时触发</strong></td>
              <td>返回省市区的值</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>
