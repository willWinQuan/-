<template>
  <div class="logo">
    <img src="https://pigjian.com/images/v-distpicker.png" width="250">
    <div class="description">
      <p>V - Distpicker 是一个简单易用的地区选择器</p>
      <small>A easy-to-use district selector component.</small>
    </div>
  </div>
</template>
