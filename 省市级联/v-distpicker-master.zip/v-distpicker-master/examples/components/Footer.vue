<template>
  <footer>
    <div class="container text-center">
      <p class="heart"></p>
      <nav>
        <a class="nav-link" href="https://github.com/jcc/v-distpicker" target="_blank">GitHub</a>
        <a class="nav-link" href="https://pigjian.com" target="_blank">About</a>
        <a class="nav-link" href="https://pigjian.com/donate" target="_blank">Donate</a>
      </nav>
    </div>
  </footer>
</template>
