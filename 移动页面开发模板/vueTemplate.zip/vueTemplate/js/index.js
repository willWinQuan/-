var mixins = {
    //默认项
    default:{
        data:function () {
            return{
                loading: true,
                ajaxLoading: false,
                //页面
                page: {
                    index: true,
                },
                //弹窗
                pop: {
                    rule: false,
                },
                // 文案
                txt:{

                },
                //弹窗黑色背景
                popupBg: false,
                fAlert: {
                    show: false,
                    text: "提示"
                },
                popAlert: {
                    show: false,
                    text: "提示"
                }
            }
        },
        methods:{
            //切换页面
            pageShow: function (id) {
                for (var i in this.page) {
                    this.page[i] = i == id ? true : false;
                }
            },

            //弹窗切换
            popShow: function (id) {
                for (var i in this.pop) {
                    this.pop[i] = i == id ? true : false;
                }
                this.popupBg = id ? true : false;
            },

            //关闭弹窗
            close: function () {
                this.popShow();
            },

            // 错误提示淡入淡出
            fadeAlert: function (text, time) {
                if (this.fadeAlertSetTime) {
                    clearTimeout(this.fadeAlertSetTime)
                }
                this.fAlert.show = true;
                this.fAlert.text = text;
                this.fadeAlertSetTime = setTimeout(function () {
                    app.fAlert.show = false;
                }, time ? time : 1500);
            },

            //跳转外链
            goUrl:function (url) {
                window.location.href = url
            },
            //替换当前页
            goGame:function (url) {
                window.location.replace(url)
            },

        }
    },
    //文案
    text:{
      data:{
          txt:{

          }
      }
    },
    //排行榜
    rankList:{
        data:function () {
            return{
                pageNum:1,
                rankList:[],
                maxPageNum:1
            }
        },
        methods:{
            showRank: function (type) {
                ajax({
                    url: sysParam.ajaxRankingList,
                    data: {
                        "is_share": type,  // 0 分数排行榜  1 助力排行榜
                        "page": this.pageNum,  //获取页数
                    }, callBack: function (data) {
                        app.popShow("rank");
                        if (app.pageNum == 1) {
                            app.rankList = data.result_data.total_page_list
                        } else {
                            app.rankList = app.rankList.concat(data.result_data.total_page_list)
                        }
                        app.maxPageNum = data.result_data.total_page_nums;

                        setTimeout(function () {
                            app.rankList.refresh();
                        }, 100)
                    }
                })
            },
        },
        created:function () {
            this.$nextTick(function () {
                app.rankList = new IScroll(".rankList ");
                app.rankList.on("scrollEnd", function (e) {
                    if (app.pageNum < app.maxPageNum && this.y == this.maxScrollY) {
                        app.pageNum++;
                        app.showRank();
                    }
                })
            })
        }
    },
    //规则
    rule:{
        data:function () {
            return{

            }
        },
        methods:{
            showRule: function () {
                this.popShow("rule");
                setTimeout(function () {
                    app.rule.refresh();
                }, 100)
            },
        },
        created:function () {
            this.$nextTick(function () {
                app.rule = new IScroll("#rule");

            })
        }
    }
};

var app = new Vue({
    mixins:[mixins.default,mixins.text],
    el: '#app',
    data:{

    },
    methods: {

    },
    created: function () {
        this.$nextTick(function () {
            //加载
            sys.lazyLoad(".body", function () {
                //加载完毕
                sys.loadingComplete();
            });
        })
    }
});

